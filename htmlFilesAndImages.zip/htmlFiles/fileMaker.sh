#!/bin/bash
if [ $1 = "bestbuy.txt" ]
then
	one="$1"
	two="$2"
else
	one="$2"
	two="$1"
fi
i=1
while read -r link ; do
    	#Skip lines without a link in the second column
   	if [ -n "$link" ]; then
		outputFile="file${i}.html"
		((i++))
        	wget -O "$outputFile" "$link"
    	fi
	done < "$one"
	#file 2
while read -r link; do
        #Skip lines without a link in the second column
        if [ -n "$link" ]; then
		outputFile="file${i}.html"
		((i++))
                wget -O "$outputFile" "$link"
        fi
        done < "$two"
